{
    "name":"Chart js",
    "depends":[
        "stock"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            


            "inventory_dashboard/static/src/js/sales_dashboard.js",
            "inventory_dashboard/static/src/xml/kpi_card.xml",
                        

        ]
    }
}






