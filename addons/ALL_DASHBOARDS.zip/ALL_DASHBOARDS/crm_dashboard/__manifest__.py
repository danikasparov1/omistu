{
    "name":"Chart js",
    "depends":[
        "crm"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            

       
            "crm_dashboard/static/src/js/newone.js",
            "crm_dashboard/static/src/xml/new.xml",

                        

        ]
    }
}






