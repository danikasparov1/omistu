{
    "name":"Chart js",
    "depends":[
        "base","sale"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            


            "general_dashboard/static/src/js/gen.js",
            "general_dashboard/static/src/xml/gen.xml",
      

        ]
    }
}






