{
    "name":"Chart js",
    "depends":[
        "hr"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            

         
            "hr_dashboard/static/src/js/next.js",
            "hr_dashboard/static/src/xml/next.xml",
        
                        

        ]
    }
}






