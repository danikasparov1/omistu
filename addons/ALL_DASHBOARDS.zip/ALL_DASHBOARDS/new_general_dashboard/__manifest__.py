{
    "name":"Chart js",
    "depends":[
        "base","sale"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            

            "new_general_dashboard/static/src/js/gen.js",

            "new_general_dashboard/static/src/xml/gen.xml",
          

        ]
    }
}






