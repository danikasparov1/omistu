{
    "name":"Chart js",
    "depends":[
        "sale"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            
            "sales_dashboard/static/src/js/chart_sample.js",
            "sales_dashboard/static/src/xml/chart_smaple.xml",
     

        ]
    }
}






