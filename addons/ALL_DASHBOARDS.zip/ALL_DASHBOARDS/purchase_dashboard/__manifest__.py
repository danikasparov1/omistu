{
    "name":"Chart js",
    "depends":[
        "base","web","account","sale","stock","purchase","crm","mrp"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            

   
            "purchase_dashboard/static/src/js/kpi_card.js",
            "purchase_dashboard/static/src/xml/purchase.xml",
      

        ]
    }
}






