{
    "name":"Chart js",
    "depends":[
        "mrp"
    ],
    "data":[
        "views/chart_menu.xml"
    ],
    "assets": {
        "web.assets_backend": [
            

      
            "manufacturing_dashboard/static/src/js/manu.js",
            "manufacturing_dashboard/static/src/xml/manu.xml",
 

        ]
    }
}






