## Module <employee_promotion_in_odoo>

#### 17.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit For Employee Promotion
