{
    "name":"Dani Icon",
     "assets": {
        "web.assets_backend": [
            "dani_settings_icon/static/src/settings_page.js",
            "dani_settings_icon/static/src/settings_page.xml"
        ]
     }
}