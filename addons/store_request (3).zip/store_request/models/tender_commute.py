from odoo import models, fields, api

class TenderValuationCommute(models.Model):
    _name = 'tender.valuation.commute'
    _description = 'Tender Valuation Commute'

    user_id = fields.Many2one('res.users', string='User', required=True)
    name = fields.Char(string='Name', readonly=True)
    title = fields.Char(string='Title', default='Tender Valuation Commute')

    score_ids = fields.One2many(
        'technical.valuation.scores',  # Related model
        'tender_id',  # Field in the related model that references this model
        string='Technical Valuation Scores'
    )

    # Computed field for total_score
    total_score = fields.Float(
        string='Total Score',
        compute='_compute_total_score',
        store=True  # Store the value in the database for faster access
    )

    @api.depends('score_ids.actual_score')
    def _compute_total_score(self):
        """
        Compute the total_score as the sum of actual_score from related technical.valuation.scores records.
        """
        for record in self:
            record.total_score = sum(record.score_ids.mapped('actual_score'))

    @api.model
    def create(self, vals):
        # Automatically derive the name from the user’s name
        user = self.env['res.users'].browse(vals.get('user_id'))
        vals['name'] = user.name if user else 'Unknown User'
        return super(TenderValuationCommute, self).create(vals)